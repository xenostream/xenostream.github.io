Workdir: module
{
	PATH:	con	"/dis/lib/workdir.dis";

	# Return current working directory

	init:	fn(): string;
};
