implement nothing;

include "sys.m";
include "draw.m";
include "math.m";
include "ipints.m";
include "crypt.m";
include "loader.m";
