Newns: module
{
	PATH:	con "/dis/lib/newns.dis";

	newns:	fn(user: string, nsfile: string): string;
	newuser:	fn(user: string, cap: string, nsfile: string): string;
};
