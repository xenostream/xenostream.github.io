#!/dis/sh.dis -n
load std
listen 'tcp!*!rstyx'  {runas $user auxi/rstyxd&}
#and {ftest -d /net/il} {listen 'il!*!rstyx' {runas $user auxi/rstyxd&}}
