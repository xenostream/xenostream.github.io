Proto : module
{
	PATH : con "/dis/install/proto.dis";

	rdproto: fn(proto : string, root : string, pcmod : Protocaller) : int;
};