Calc: module {

	parseexpr: fn(s: string, a, b, c: big): (big, string);
	init:	fn(nil: ref Draw->Context, nil: list of string);
NUMBER: con	57346;
UNARYMINUS: con	57347;
};
