#include	"dat.h"
#include	<dynld.h>

/* dummy export table */

Dynsym _exporttab[] = { 0, 0, nil };
