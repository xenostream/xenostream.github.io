#include "devfs-posix.c"

static vlong
osdisksize(int fd)
{
	return 0;
}
