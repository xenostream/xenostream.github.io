/*
 * All the virtual machine interfaces
 */
#include "/usr/inferno/include/interp.h"
#include "/usr/inferno/include/isa.h"
#include "/usr/inferno/libinterp/runt.h"

int srvf2c(char*, char*, int, Sys_FileIO*);
