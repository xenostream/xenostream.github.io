char*	argv0 = 0;
