#include "lib9.h"

char*
getuser(void)
{
	/* could do better, but result isn't really used */
	return "unknown";
}
